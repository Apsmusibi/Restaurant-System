/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Apollo Musibi
 */
public class Customer {

   private int cusid;
    int orderno;
    public Customer(int someid, int someorder)
    {
        cusid=someid;
        orderno=someorder;
    }
public int placeOrder(int order)
{
    orderno=order;
    return order;   
}
    
    
}
