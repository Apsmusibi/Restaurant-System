/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Apollo Musibi
 */
public class Chef{
    private int chefid;
    private String chefname;
    int mealid;
    public Chef(int someid, String somename,int somemeal)
    {
        chefid=someid;
        chefname=somename;
        mealid=somemeal;
    }
    
}
