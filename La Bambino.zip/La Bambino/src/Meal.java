/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Apollo Musibi
 */
public class Meal {
    int mealid;
    String mealname;
    int price;
    public Meal(int someid, String somename, int someprice)
    {
        mealid=someid;
        mealname=somename;
        price=someprice;
    }
}
