/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Apollo Musibi
 */
public class Supervisor {
    int supid;
    String supname;
    int stafid;
    public Supervisor(int someid, String somename, int somestaff)
    {
        supid=someid;
        supname=somename;
        stafid=somestaff;
    }
    
}
